Issue ant from this directory, and it will create an out directory with HTLM
in it.

You should do this in the already built example, not inside the
src/examples/ant directory!
